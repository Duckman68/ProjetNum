import numpy as np
import math
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import time

# Initialisation du chrono
start_time = time.time()

# Paramètres numériques
dt = 1e-7         # pas de temps
dx = 0.001        # pas d’espace
nx = int(1 / dx) * 2
nt = 120000       # nombre de pas de temps
nd = int(nt / 1000) + 1
s = dt / dx**2

# Paramètres du paquet d’ondes
xc = 0.3          # position initiale du paquet
sigma = 0.05      # largeur du paquet
A = 1 / (math.sqrt(sigma * math.sqrt(math.pi)))

v0 = -200         # profondeur du puits (négatif car attractif)
e = 15            # rapport E / |V0|
E = e * abs(v0)
k = math.sqrt(2 * abs(E))  # vecteur d’onde associé à l’énergie

# Grille spatiale
o = np.linspace(0, (nx - 1) * dx, nx)

# Potentiel gaussien plus réaliste
x0_potentiel = 1.1      # centre du puits
sigma_potentiel = 0.05  # largeur du puits
V = v0 * np.exp(-((o - x0_potentiel)**2) / (2 * sigma_potentiel**2))

# Paquet d’ondes initial
cpt = A * np.exp(1j * k * o - ((o - xc) ** 2) / (2 * sigma ** 2))

# Initialisation de la densité et des composantes réelle / imaginaire
densite = np.zeros((nt, nx))
densite[0, :] = np.abs(cpt)**2
final_densite = np.zeros((nd, nx))

re = np.real(cpt)
im = np.imag(cpt)
b = np.zeros(nx)

# Évolution temporelle
it = 0
for i in range(1, nt):
    if i % 2 != 0:
        b[1:-1] = im[1:-1]
        im[1:-1] += s * (re[2:] + re[:-2]) - 2 * re[1:-1] * (s + V[1:-1] * dt)
        densite[i, 1:-1] = re[1:-1]**2 + im[1:-1] * b[1:-1]
    else:
        re[1:-1] -= s * (im[2:] + im[:-2]) - 2 * im[1:-1] * (s + V[1:-1] * dt)
    
    if (i - 1) % 1000 == 0:
        final_densite[it, :] = densite[i, :]
        it += 1

# Animation
def init():
    line.set_data([], [])
    return line,

def animate(j):
    line.set_data(o, final_densite[j, :])
    return line,

plot_title = "Propagation d’un paquet d’ondes dans un puits gaussien – E/|V0| = " + str(e)
fig = plt.figure()
line, = plt.plot([], [])
plt.ylim(0, 13)
plt.xlim(0, 2)
plt.plot(o, V, label="Potentiel gaussien")
plt.title(plot_title)
plt.xlabel("x")
plt.ylabel("Densité de probabilité")
plt.legend()
ani = animation.FuncAnimation(fig, animate, init_func=init, frames=nd, blit=False, interval=100, repeat=False)
plt.show()
