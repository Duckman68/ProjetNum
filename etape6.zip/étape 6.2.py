import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import eigh_tridiagonal

# Paramètres du puits gaussien
V0 = 200                     # Profondeur positive (on met le signe - dans V(x))
x0 = 1.1                     # Position du centre du puits
sigma = 0.05                 # Largeur du puits
L = 2.0                      # Longueur du domaine
N = 2000                     # Nombre de points spatiaux
nb_etats_max = 8             # Combien d'états positifs on souhaite afficher

# Grille spatiale
x = np.linspace(0, L, N)
dx = x[1] - x[0]

# Construction du potentiel gaussien
V = -V0 * np.exp(-((x - x0)**2) / (2 * sigma**2))

# ⚙️ Construction du Hamiltonien tridiagonal
diag_principale = V + 1.0 / dx**2
diag_hors = -0.5 / dx**2 * np.ones(N - 1)

# Résolution de l’équation de Schrödinger
energies, psi = eigh_tridiagonal(diag_principale, diag_hors, select='a')
indices_pos = np.where(energies > 0)[0]
indices_utiles = indices_pos[:nb_etats_max]
energies_pos = energies[indices_utiles]
psi_pos = psi[:, indices_utiles]

# Normalisation des fonctions d’onde
for n in range(len(indices_utiles)):
    norme = np.sqrt(np.sum(np.abs(psi_pos[:, n])**2) * dx)
    psi_pos[:, n] /= norme

# Affichage des états stationnaires
plt.figure(figsize=(10, 6))
for n in range(len(energies_pos)):
    plt.plot(x, psi_pos[:, n] + energies_pos[n], label=f"État {n} : E = {energies_pos[n]:.2f}")

plt.plot(x, V, 'k--', label='Potentiel gaussien')
plt.title("États stationnaires à énergie positive – Puits gaussien")
plt.xlabel("x")
plt.ylabel("Énergie / ψ(x)")
plt.grid()
plt.legend()
plt.tight_layout()
plt.show()

# Affichage console
print("États stationnaires à énergie positive :")
for i, e in enumerate(energies_pos):
    print(f"  État {i} : E = {e:.4f}")
